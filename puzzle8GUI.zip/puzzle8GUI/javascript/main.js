function myFunction() {
    console.log("hola bitches")  // The function returns the product of p1 and p2
  }